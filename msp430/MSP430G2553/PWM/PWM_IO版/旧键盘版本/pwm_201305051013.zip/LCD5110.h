/**********************************************
 *
 * 		Author	:		Shawn Guo
 * 		Date	:		2013/4/14
 *      Last    :       2013/4/16
 * 		Tool    :	MSP430G2553
 * 		Notes	:		LCD5110驱动
 *
 *         1.VCC    2.GND   3.SCE   4.RESET
 *         5.D/C    6.SDIN  7.SCLK  8.LED+
 *
 *---------------------------------------
 *          SCE---> P2.0
 *          RST---> P2.1
 *          D/C---> P2.2
 *          SDIN--> P2.3
 *          SCLK--> P2.4
 **********************************************/


#ifndef __LCD5110__            // 头文件保护策略
#define __LCD5110__

// =======================LCD I/O端口宏定义设置===========================
#define  LCD_CE_1       (P2OUT |= BIT0)
#define  LCD_CE_0       (P2OUT &=~BIT0)      // 低电平有效使能

#define  LCD_RST_1      (P2OUT |= BIT1)
#define  LCD_RST_0      (P2OUT &=~BIT1)     // 低电平有效

#define  LCD_DC_1       (P2OUT |= BIT2)
#define  LCD_DC_0       (P2OUT &=~BIT2)

#define  SDIN_1         (P2OUT |= BIT3)
#define  SDIN_0         (P2OUT &=~BIT3)

#define  SCLK_1         (P2OUT |= BIT4)
#define  SCLK_0         (P2OUT &=~BIT4)        // SCLK频率范围0~4MHZ
//时钟周期:最小250ns
// =======================LCD 功能函数===========================
void LCD_IO_set(void);    // I/O口配置
void LCD_Init(void);      // LCD初始化
void LCD_Clear(void);      // LCD RAM清零
void LCD_Write_String(unsigned char X,unsigned char Y,char *s); // 写入字符串
void LCD_Write_Char(unsigned char c);   // 写入ASCII字符


// 给LCD写入数据/命令。 当command = 0，即写入命令，命令内容为dat
//             当command = 1,即写入数据，数据内容为dat
void LCD_Write_Byte(unsigned char dat, unsigned char dc);   // 写入一字节数据/命令

void LCD_Set_XY(unsigned char X, unsigned char Y);  //设置位置离开(X,Y),LCD5110一行可以显示14个字符，一个字符占6列，总共84列

#endif
