/**********************************************
 *
 * 		Author	:		Shawn Guo
 * 		Date	:		2013/5/4
 *      Last    :       2013/5/4
 * 		Notes	:       PWM方波输出
 * 		Tool    :	    MSP430G2553
 *
 *      P1.2 ---> TA0.2
 *      Timer_A (DCO CLK)
 *
 *      P1.0 KEY_A 控制频率，100us步进
 *      P1.3 KEY_c 控制占空比，1%步进
 *      P1.4 方波信号
 *      p1.5 方波信号
 *
 *      P1.6 P1.7  ADC双通道接入， A6为高电平模式，A7为低电平模式
 **********************************************/
#include <msp430g2553.h>
#include "PWM.h"
#include "ADC.h"
#include "LCD5110.h"

#define CALBC1_M CALBC1_1MHZ
#define CALDCO_M CALDCO_1MHZ

extern double PWM_F; // 频率默认100HZ
extern double PWM_DC; // 占空比默认50%
extern long int PWM_CLK; // 1M DCO CLK

extern char ADC_LCD_BUFFER1[]; // LCD buffer, (x.xxxv eg. 3.000v)
extern char ADC_LCD_BUFFER2[];
extern char ADC_LCD_BUFFER3[];

void Config_Clocks(); //配置时钟
void Config_Timer0(); //设置定时器
void Config_Port();   // 中断端口配置

int ADC_FLAG = 0;   //默认AD关闭，ADC_FLAG = 1，高电平模式； ADC_FLAG = 2， 低电平模式
unsigned int LOW_CLK = 0, HIGH_CLK = 0, LOW_OVERFLOW = 0, HIGH_OVERFLOW = 0; // 高电平，低电平的持续CLK计数器,以及对应的定时溢出值
int LOW_START_CLK = 0, LOW_END_CLK = 0, HIGH_START_CLK = 0, HIGH_END_CLK = 0; //记录高电平，低电平开始与结束时刻的CLK数值，以计算出其CLK
int OVERFLOW_CLK = 0; // 定时器溢出需要的CLK数目

extern unsigned int ADC_DAT; //AD sample data
extern unsigned int ADC_MAX_DAT; // max v
extern unsigned int ADC_MIN_DAT; // min v
extern unsigned int ADC_AVE_DAT; // average v

int ADC_SAMPLE_COUNT = 0;  // AD采样次数
int ADC_F = 0; // ADC采样信号计算频率
double ADC_DC = 0; //ADC采样信号占空比
int CLEAR_COUNT = 0;
double PWM_T = 0.001; // 1ms

void main(void)
{
    WDTCTL = WDTPW + WDTHOLD;                 // Stop WDT
    Config_Clocks();
    Config_Timer0();
    Config_Port();

    PWM_Init();            //PWM配置
    PWM_CLK = 1000000;
    PWM_Set(PWM_F, PWM_DC);

    LCD_IO_set();
    Config_Clocks(); //配置时钟
    LCD_Init(); //初始化液晶
    LCD_Clear();

    ADC_Init();

    _EINT();
    while(1);
}

void Config_Clocks() //配置时钟，该时钟将决定 定时器 溢出的时间
{
    BCSCTL1 = (CALBC1_M); // Set range
    DCOCTL = (CALDCO_M); // Set DCO step + modulation
    BCSCTL3 |= LFXT1S_2;  /* Mode 2 for LFXT1 : VLO */

    IFG1 &= ~OFIFG; // Clear OSCFault flag

// BCSCTL2, Basic Clock System Control Register 2

    // SELMx , Select MCLK. These bits select the MCLK source.
    // 00 DCOCLK    01 DCOCLK  11 LFXT1CLK or VLOCLK
    // 10 XT2CLK when XT2 oscillator present on-chip.
    //LFXT1CLK or VLOCLK when XT2 oscillator not presenton-chip.

    //SELS , Select SMCLK. This bit selects the SMCLK source.
    // 0 DCOCLK
    //1 XT2CLK when XT2 oscillator present.
    //LFXT1CLK or VLOCLK when XT2 oscillator not present

    //DIVMx , Divider for MCLK
    // 00 /1	01 /2	10 /4	11 /8
    //DIVSx , Divider for SMCLK
    //00 /1		01 /2	10 /4	11 /8

    //DCOR , DCO resistor select. Not available in all devices. See the device-specific data sheet.
    //0 Internal resistor
    //1 External resistor

    //    MCLK=DC0       不分频
    BCSCTL2 |= SELM_0 + DIVM_0 + DIVS_0; // SMCLK = DCO
}

void Config_Timer0() //设置定时器
{
    //TACTL,Timer_A Control Register
    //TASSELx, Timer_A clock source select
    //00 TACLK    01 ACLK    	10 SMCLK

    //MCx, Mode control.
    //00 Stop mode: the timer is halted.
    //01 Up mode: the timer counts up to TACCR0.
    //10 Continuous mode: the timer counts up to 0FFFFh.
    //11 Up/down mode: the timer counts up to TACCR0 then down to 0000h.

    //TAIE ,Timer_A interrupt enable.
    //0 Interrupt disabled
    //1 Interrupt enabled

    //TACLR ,Timer_A clear.

    //IDx , 7-6 Input divider.
    //00 /1           01 /2       10 /4         11 /8

    //      SMCLK
    TACTL = TASSEL_2 + MC_1 + TACLR + ID_0; //TA基准时钟为SMCLK，且SMCLK与MCLK频率相同
}

void Config_Port()   // 中断端口配置
{
    P1DIR &= ~BIT0; //  P1.0设为输入
    P1IES &= ~BIT0; //  P1.0中断触发沿：上升沿；
    P1IE |= BIT0; //    开启P1.0 I/O中断
    P1REN |= BIT0;
    P1OUT &= ~BIT0;

    P1DIR &= ~BIT3; //  P1.3设为输入
    P1IES &= ~BIT3; //  P1.3中断触发沿：上升沿；
    P1IE |= BIT3; //    开启P1.3 I/O中断
    P1REN |= BIT3;
    P1OUT &= ~BIT3;

    P1DIR &= ~BIT4; //  P1.4设为输入
    P1IES &= ~BIT4; //  P1.4中断触发沿：上升沿； 表示高电平模式
    P1IE |= BIT4; //    开启P1.4 I/O中断
    P1REN |= BIT4;
    P1OUT &= ~BIT4;

    P1DIR &= ~BIT5; //  P1.5设为输入
    P1IES |= BIT5; //  P1.5中断触发沿：上升沿；表示低电平模式
    P1IE |= BIT5; //    开启P1.5 I/O中断
    P1REN |= BIT5;
    P1OUT &= ~BIT5;

    P1DIR &= ~BIT6;
    P1REN |= BIT6;
    P1OUT &= ~BIT6;

    P1DIR &= ~BIT7;
    P1REN |= BIT7;
    P1OUT &= ~BIT7;

}

//  I/O中断程序，键盘控制响应事件的发生
#pragma vector=PORT1_VECTOR
__interrupt void P1_ISR (void)
{
    if(P1IFG & BIT0) //键盘控制频率步进量,100us步进
    {
    	int i = 0;
    	for(i = 0; i < 10000; i++);
    	if(P1IFG & BIT0){
    		PWM_T += 0.0001;
    		PWM_F = (int)(1.0 / PWM_T);
    		if(PWM_F < 100) PWM_F = 1000;
    		PWM_Set(PWM_F, PWM_DC);
    	}
    }
    else if(P1IFG & BIT3) //键盘控制占空比，1%步进
    {    	int i = 0;
		for(i = 0; i < 10000; i++);
		if(P1IFG & BIT3){
        PWM_DC += 0.01;
        if(PWM_DC > 1.0) PWM_DC = 0;
        PWM_Set(PWM_F, PWM_DC);
		}
    }
    else if(P1IFG & BIT4) // 方波输入端口，上升沿触发，表示高电平采样模式，开启通道A6
    {
        // 记录这一次的HIGH_Start_clk;
        HIGH_START_CLK = TAR;

        ADC_FLAG = 1; // 配置ADC_FLAG标志,设为高电平模式；

        //计算上一次低电平模式的LOW_CLK；
        LOW_END_CLK = HIGH_START_CLK;
        LOW_CLK = LOW_END_CLK + LOW_OVERFLOW * OVERFLOW_CLK - LOW_START_CLK;



        LOW_OVERFLOW = 0; //清零；
        LOW_END_CLK = LOW_START_CLK = 0;

        ADC10CTL0 &= ~ENC;
        ADC10CTL1 = INCH_6 + ADC10SSEL_3;  // input A6

        V2char(ADC_MAX_DAT, ADC_LCD_BUFFER1);
        LCD_Write_String(0, 0,ADC_LCD_BUFFER1);

        ADC10CTL0 |= ENC + ADC10SC;             // Sampling and conversion start

        if(++CLEAR_COUNT > 50) {
        	ADC_MAX_DAT = 0;
        	ADC_MIN_DAT = 0;
        	ADC_AVE_DAT = 0;
        	CLEAR_COUNT = 0;
        }
    }
    else if(P1IFG & BIT5) // 方波输入端口，上升沿触发，表示低电平采样模式；开启通道A7
    {
        // 记录这一次的LOW_Start_clk;
        LOW_START_CLK = TAR;

        ADC_FLAG = 2; // 配置ADC_FLAG标志,设为低电平模式；

        //计算上一次高电平模式的HIGH_CLK；
        HIGH_END_CLK = LOW_START_CLK;
        HIGH_CLK = HIGH_END_CLK + HIGH_OVERFLOW * OVERFLOW_CLK - HIGH_START_CLK;

        HIGH_OVERFLOW = 0; //清零；
        HIGH_END_CLK = HIGH_START_CLK = 0;

        ADC10CTL0 &= ~ENC;
        ADC10CTL1 = INCH_7 + ADC10SSEL_3;  // input A7

        V2char(ADC_MIN_DAT, ADC_LCD_BUFFER2);
        LCD_Write_String(0, 1, ADC_LCD_BUFFER2);

        ADC10CTL0 |= ENC + ADC10SC;             // Sampling and conversion start

        if(++CLEAR_COUNT > 50) {
        	ADC_MAX_DAT = 0;
        	ADC_MIN_DAT = 0;
        	ADC_AVE_DAT = 0;
        	CLEAR_COUNT = 0;
        }
    }

//    ADC_F = (int)((double)PWM_CLK  / (HIGH_CLK + LOW_CLK));
//    ADC_DC = ((double)HIGH_CLK / (HIGH_CLK + LOW_CLK));
    P1IFG = 0;         // P1端口的中断标志位清零，等待下一次中断
}


// ADC10 interrupt service routine
#pragma vector=ADC10_VECTOR
__interrupt void ADC10_ISR(void)
{
    if(ADC_FLAG == 1) // 高电平模式测量
    {
        ADC_DAT = (unsigned int)((ADC10MEM * (ADC_VREF1 - ADC_VREF2) / 1023 + ADC_VREF2) * V_GAIN);
       // ADC_DAT -= V_OFF_SET;
        if(ADC_DAT > ADC_MAX_DAT) ADC_MAX_DAT = ADC_DAT;
    }
    else   //低电平模式测量
    {
        ADC_DAT = (unsigned int)((ADC10MEM * (ADC_VREF1 - ADC_VREF2) / 1023 + ADC_VREF2) * V_GAIN);
       // ADC_DAT -= V_OFF_SET;
        if(ADC_DAT > ADC_MIN_DAT) ADC_MIN_DAT = ADC_DAT;
    }
}

/*
ADC10CTL0 |= ENC + ADC10SC;             // Sampling and conversion start
*/
