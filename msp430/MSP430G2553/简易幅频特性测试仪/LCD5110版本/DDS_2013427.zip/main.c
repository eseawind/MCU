/**********************************************
 *
 * 		Author	:		Shawn Guo
 * 		Date	:		2013/4/21
 *      Last    :       2013/4/27
 * 		Notes	:       DDS
 * 		Tool    :	    MSP430G2553
 *
 **********************************************/
#include <msp430g2553.h>
#include "LCD5110.h"
#include "DAC.h"

// ===============================精确延时宏定义=========================
#define CPU_F ((double)16000000)        // 这里的CPU_F需要自己配置，这里配置为1MHZ
#define DELAY_US(x) __delay_cycles((long)(CPU_F*(double)x/1000000.0))
#define DELAY_MS(x) __delay_cycles((long)(CPU_F*(double)x/1000.0))

#define ADC_VREF1   3.545
#define ADC_VREF2   0
#define V_OFF_SET 0    //AD输入为0时的偏置CODE
#define V_GAIN  1000            //电压显示增益


void Config_Clocks();


int STEP_K = 2 * 800;       // DDS 步进量
const int SSTEP_K = 20;        // 步进量的步进量
const int NUM = 2 * 4096;       // 波形ROM数组， 4096个数据，分为高低位，ROM的大小决定DAC的输出精度；
int TIME_NUM = 80;        //定时器溢出周期数
extern const unsigned char SIN_ROM[];  //波形数据，存放在DAC.c文件里
unsigned int n = 0;

void ADC10_Init(void);
void V2char(unsigned int temp);      // dat from int to char for LCD5110
char STR_F[7] = "0.000v"; // LCD buffer, (x.xxxv eg. 3.000v)
unsigned int dat = 0; //AD sample data
unsigned int MAX_DAT = 0; // feng zhi

void main()
{
    // Stop watchdog timer to prevent time out reset
    WDTCTL = WDTPW + WDTHOLD;
    Config_Clocks();

    DAC_Init();         //DAC初始化配置
    ADC10_Init();
    P1SEL2 |= BIT1;   // open the P1.1 to sample as A1

    LCD_IO_set();
    LCD_Init();
    LCD_Clear();
    LCD_Write_String(0,0,"v = ");

    //定时器配置;

    TACTL |= TASSEL_2 + ID_0 + MC_1 + TACLR;
    CCTL0 = CCIE;
    TACCR0 = TIME_NUM - 1;

    //开启SPI中断允许

    _EINT();

    //数据放在定时中断中发送
    for (;;)
    {
        ADC10CTL0 |= ENC + ADC10SC;             // Sampling and conversion start
        V2char(MAX_DAT);
        LCD_Write_String(24,0,STR_F);
    }
}


#pragma vector=TIMER0_A0_VECTOR
__interrupt void TIMER0_A0(void)
{
    DAC_CE_0;
    IFG2 &= ~UCA0RXIFG;
    UCA0TXBUF = SIN_ROM[n];
    // while(!(IFG2 & UCA0TXIFG));
    // _NOP();
    UCA0TXBUF = SIN_ROM[n+1];
    n += STEP_K;                //模拟DDS加法器，每次递增一个步进量
    if(n >= NUM)
        n = 0;
    if(P1IN & BIT0)        //键盘控制频率步进量
    {
        DELAY_MS(100);
        if(P1IN & BIT0)
        {
            STEP_K += SSTEP_K;
            n = 0;
            DELAY_MS(300);
        }

    }
    if(P1IN & BIT3)
    {
        DELAY_MS(100);
        if(P1IN & BIT3)
        {
            MAX_DAT = 0;
            DELAY_MS(300);
        }

    }
    while(!(IFG2 & UCA0RXIFG));

    DAC_CE_1; //拉高使能信号，使得转移寄存器中的数据移入目标锁存
}


void Config_Clocks()
{
    BCSCTL1 = CALBC1_16MHZ; // Set range
    DCOCTL = CALDCO_16MHZ; // Set DCO step + modulation
    BCSCTL3 |= LFXT1S_2;
// BCSCTL2, Basic Clock System Control Register 2

    // SELMx , Select MCLK. These bits select the MCLK source.
    // 00 DCOCLK    01 DCOCLK  11 LFXT1CLK or VLOCLK
    // 10 XT2CLK when XT2 oscillator present on-chip.
    //LFXT1CLK or VLOCLK when XT2 oscillator not presenton-chip.

    //SELS , Select SMCLK. This bit selects the SMCLK source.
    // 0 DCOCLK
    //1 XT2CLK when XT2 oscillator present.
    //LFXT1CLK or VLOCLK when XT2 oscillator not present

    //DIVMx , Divider for MCLK
    // 00 /1	01 /2	10 /4	11 /8
    //DIVSx , Divider for SMCLK
    //00 /1		01 /2	10 /4	11 /8

    //DCOR , DCO resistor select. Not available in all devices. See the device-specific data sheet.
    //0 Internal resistor
    //1 External resistor

    //    MCLK=DC0
    BCSCTL2 |= SELM_0 + DIVM_0 + DIVS_0; // SMCLK = DCO
}

void ADC10_Init(void)
{
    //----------------ADC10CTL0
    //ADC10SC,  Start conversion.
    // ADC10IE          ADC10IFG
    //ENC:    Enable conversion,if ENC=1, ADC10 enabled

    //---Can be modified only when ((   ENC = 0     ))
    //ADC10SHTx : ADC10 sample-and-hold time
    // 00 4 脳 ADC10CLKs   01  8xCLK       10      16xCLKS       11  64xCLKS
    //SREFx,    Select reference.
    //ADC10SR,  ADC10 sampling rate.    0,~200 ksps     1,~50 ksps
    //----------------ADC10CTL0----END------
    //  SREF_1 VR+ = AVCC and VR- = VSS

    ADC10CTL0 = SREF_0 + ADC10SHT_2 + ADC10IE + ADC10ON;

    //----------------ADC10CTL1
    // INCHx , Input channel select.
    //0000 A0  //0001 A1  //0010 A2    //0011 A3    //0100 A4
    //0101 A5    //0110 A6    //0111 A7    //1000 VeREF+    //1001 VREF-/VeREF-
    //1010 Temperature sensor    //1011 (VCC - VSS) / 2

    // ADC10DIVx Bits 7-5 ADC10 clock divider
    //000 /1    //001 /2    //010 /3    //011 /4
    //100 /5    //101 /6    //110 /7    //111 /8

    //ADC10SSELx Bits 4-3 ADC10 clock source select
    //00 ADC10OSC   //01 ACLK    //10 MCLK    //11 SMCLK

    //SHSx Bits 11-10 Sample-and-hold source select.
    //00 ADC10SC bit
    //01 Timer_A.OUT1(1)        //10 Timer_A.OUT0(1)
    //11 Timer_A.OUT2 (Timer_A.OUT1 on MSP430F20x0, MSP430G2x31, and MSP430G2x30 devices)(1)

    //CONSEQx Bits 2-1 Conversion sequence mode select
    //00 Single-channel-single-conversion
    //01 Sequence-of-channels
    //10 Repeat-single-channel
    //11 Repeat-sequence-of-channels

    //ADC10BUSY Bit 0 ADC10 busy. This bit indicates an active sample or conversion operation
    //0 No operation is active.
    //1 A sequence, sample, or conversion is active.

    //----------------ADC10CTL1----END------
    ADC10CTL1 = INCH_1 + ADC10SSEL_3;  // input A1

    ADC10AE0 |= 0x02;                         // PA.1 ADC option select
}


// ADC10 interrupt service routine
#pragma vector=ADC10_VECTOR
__interrupt void ADC10_ISR(void)
{
    dat = (unsigned int)((ADC10MEM * (ADC_VREF1 - ADC_VREF2) / 1023 + ADC_VREF2) * V_GAIN);
    dat -= V_OFF_SET;
    if(dat > MAX_DAT) MAX_DAT = dat;
}

void V2char(unsigned int temp)      // dat from int to char for LCD5110
{
    STR_F[4] = temp % 10 + '0';
    temp /= 10;
    STR_F[3] = temp % 10 + '0';
    temp /= 10;
    STR_F[2] = temp % 10 + '0';
    temp /= 10;
    // STR_F[1] = '.';
    STR_F[0] = temp % 10 + '0';
}

