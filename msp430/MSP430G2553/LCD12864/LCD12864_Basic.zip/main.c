
#include <msp430g2553.h>
#include "LCD12864.h"

void main()
{
    WDTCTL = WDTPW + WDTHOLD;

    LCD_Init();
    LCD_Write_Data('a');
    LCD_Write_Data('z');
    LCD_Write_Data('x');
}
