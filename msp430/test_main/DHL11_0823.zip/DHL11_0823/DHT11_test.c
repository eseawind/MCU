/**********************************************
 *
 * 		Author	:		Shawn Guo
 *      Mail    :       iguoxiaopeng@gmail.com
 * 		Date	:       2013/8/23
 *      Last    :       2013/8/23
 * 		Notes	:       DHT11_TEST
 * 		Tool    :       DHT11_TEST
 **********************************************/



#include <msp430f2618.h>
#include "clock.h"
#include "LCD5110.h"
#include "DHT11.h"

char LCD_MAIN_BUFFER1[] = "T :";
char LCD_MAIN_BUFFER2[] = "RH:";

void main()
{
    WDTCTL = WDTPW + WDTHOLD;

    Clock_Init(0,0,0,CPU_FF); // 1M DCO
    LCD5110_Init();
    LCD5110_Write_String(0, 0, LCD_MAIN_BUFFER1);
    LCD5110_Write_String(0, 1, LCD_MAIN_BUFFER2);

    DHT11_Init_IO();
    DELAY_MS(1000); //��ʼ��ǰ1s���ȶ�, �Թ�.

    while(1)
    {
        DHT11_Sample();
        LCD5110_Long2Char(DHT11_T_DATAH);
        LCD5110_Write_String(18, 0, 0);
        LCD5110_Long2Char(DHT11_RH_DATAH);
        LCD5110_Write_String(18, 1, 0);
        DELAY_MS(1000);
    }

}
