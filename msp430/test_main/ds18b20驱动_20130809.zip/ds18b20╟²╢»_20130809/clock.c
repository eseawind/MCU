/**********************************************
 *
 * 		Author	:		Shawn Guo
 *      Mail    :       iguoxiaopeng@gmail.com
 * 		Date	:		2013/7/23
 *      Last    :       2013/7/24
 * 		Notes	:       clock system
 * 		Tool    :	    MSP430x2xx
 **********************************************/
/*****************************************************************************
* @file       clock.c
* @addtogroup CLOCK
* @{
******************************************************************************/
#include <msp430f2618.h>
#include "clock.h"



/***************************************************************************//**
 * @brief  Initialize the Clock sysyem - configure MCLK,SMCLK,ACLK,DCO
 * @param
 *      parameter               source          div
 *-----------------------------------------------------------------------------
 *      mclk_config =   0       DCO             /1
 *                      1       DCO             /2
 *                      2       DCO             /4
 *                      3       DCO             /8
 *
 *                      4       XT2             /1
 *                      5       XT2             /2
 *                      6       XT2             /4
 *                      7       XT2             /8
 *------------------------------------------------------------------------------
 *    smclk_config =    0       DCO             /1
 *                      1       DCO             /2
 *                      2       DCO             /4
 *                      3       DCO             /8
 *
 *                      4       XT2             /1
 *                      5       XT2             /2
 *                      6       XT2             /4
 *                      7       XT2             /8
 *------------------------------------------------------------------------------
 *    aclk_config =     0       VLOCLK          /1
 *                      1       VLOCLK          /2
 *                      2       VLOCLK          /4
 *                      3       VLOCLK          /8
 *
 *                      4       LFXT1           /1
 *                      5       LFXT1           /2
 *                      6       LFXT1           /4
 *                      7       LFXT1           /8
 *------------------------------------------------------------------------------
 *
 *    dco_config  =     1       1M
 *                      8       8M
 *                      12      12M
 *                      16      16M
 *
 *------------------------------------------------------------------------------
 * @return none
 ******************************************************************************/
void Clock_Init(unsigned char mclk_config, unsigned char smclk_config, unsigned char aclk_config, unsigned char dco_config)
{
    if(mclk_config < 4)  //MCLK ����
    {
        // DCO
        //BCSCTL1 |= XT2OFF; // XT2OFFĬ��Ϊ1
        //BCSCTL2 |= SELM_0;

        if(mclk_config == 0)
            /*BCSCTL2 |= DIVM_0*/
            ;
        else if(mclk_config == 1) BCSCTL2 |= DIVM_1;
        else if(mclk_config == 2) BCSCTL2 |= DIVM_2;
        else BCSCTL2 |= DIVM_3;
    }
    else
    {
        //XT2
        BCSCTL1 &= ~XT2OFF; // XT2OFFĬ��Ϊ1
        BCSCTL2 |= SELM_2;
        BCSCTL3 |= XT2S_2; /* Ĭ������: Mode 2 for XT2 : 2 - 16 MHz */

        if(mclk_config == 4)
            //BCSCTL2 |= DIVM_0
            ;
        else if(mclk_config == 5) BCSCTL2 |= DIVM_1;
        else if(mclk_config == 6) BCSCTL2 |= DIVM_2;
        else BCSCTL2 |= DIVM_3;
    }


    if(smclk_config < 4) //SMCLK ����
    {
        //DCO
        // BCSCTL2 &= ~SELS;
        if(smclk_config == 0)
            //BCSCTL2 |= DIVS_0
            ;
        else if(smclk_config == 1) BCSCTL2 |= DIVS_1;
        else if(smclk_config == 2) BCSCTL2 |= DIVS_2;
        else  BCSCTL2 |= DIVS_3;
    }
    else
    {
        //XT2CLK
        BCSCTL2 |= SELS;

        if(smclk_config == 4)
            //BCSCTL2 |= DIVS_0
            ;
        else if(smclk_config == 5) BCSCTL2 |= DIVS_1;
        else if(smclk_config == 6) BCSCTL2 |= DIVS_2;
        else  BCSCTL2 |= DIVS_3;
    }


    if(aclk_config < 4) //ACLK ����
    {
        //VLOCLK
        BCSCTL3 |= LFXT1S_2;

        if(aclk_config == 0)
            ;
        else if(aclk_config == 1) BCSCTL1 |= DIVA_1;
        else if(aclk_config == 2) BCSCTL1 |= DIVA_2;
        else BCSCTL1 |= DIVA_3;
    }
    else
    {
        //32768-Hz crystal on LFXT1
        BCSCTL3 &= ~(LFXT1S_2 + LFXT1S_1); // BIT5 + BIT4
        if(aclk_config == 0)
            ;
        else if(aclk_config == 1) BCSCTL1 |= DIVA_1;
        else if(aclk_config == 2) BCSCTL1 |= DIVA_2;
        else BCSCTL1 |= DIVA_3;
    }

    //DCO����
    if(dco_config == 1)
    {
        BCSCTL1 =  CALBC1_1MHZ;    // Set range
        DCOCTL = CALDCO_1MHZ;      // Set DCO step + modulation
    }
    else if(dco_config == 8)
    {
        BCSCTL1 =  CALBC1_8MHZ;    // Set range
        DCOCTL = CALDCO_8MHZ;      // Set DCO step + modulation
    }
    else if(dco_config == 12)
    {
        BCSCTL1 =  CALBC1_12MHZ;    // Set range
        DCOCTL = CALDCO_12MHZ;      // Set DCO step + modulation
    }
    else if(dco_config == 16)
    {
        BCSCTL1 =  CALBC1_16MHZ;    // Set range
        DCOCTL = CALDCO_16MHZ;      // Set DCO step + modulation
    }
    else
    {
        BCSCTL1 =  CALBC1_1MHZ;    // Set range
        DCOCTL = CALDCO_1MHZ;      // Set DCO step + modulation
    }


    IFG1 &= ~OFIFG; // Clear OSCFault flag

}








/*DCOCTL �Ĵ���*/
/********************************************************************************
* bit7     bit6     bit5     bit4     bit3     bit2     bit1     bit0
* DCO.2    CCO.1    DCO.0    MOD.4    MOD.3    MOD.2    MOD.1    MOD.0
*********************************************************************************
* ��RSELxѡ���Ժ�
* DCO.0����DCO.2����8��Ƶ��֮һ���ɷֶε���DCOCLKƵ�ʣ���������Ƶ�����10%��
* ��Ƶ����ע��ֱ���������ĵ������塣
----------------------------------------------------------------
* MOD.O����MOD.4������32��DCO�����в����fdco+l���ڸ������������µ�DCO����
* ��ΪfDco���ڣ������л�DCO��DCO+1ѡ�������Ƶ�ʡ����DCO����Ϊ7����ʾ��
* ��ѡ��������ʣ���ʱ��������MOD.O-MOD.4����Ƶ�ʵ�����
* Not useable when DCOx = 7.
*********************************************************************************/



/*BCSCTL1 �Ĵ���*/

/**********************************************************************************
*
* bit7      bit6      bit5      bit4     bit3     bit2    bit1     bit0
*
* XT2OFF    XTS       DIVA.1    DIVA.0   Rse1.3   Rse1.2  Rse1.1   Rse1.0
***********************************************************************************
*XT2OFF���� XT2 �����Ŀ�����رա�
*XT2OFF=0��XT2����������
*XT2OFF=1��XT2�������ر�(Ĭ��XT2�ر�)��
----------------------------------------------------------------
*XTS���� LFXTl ����ģ�䣬ѡ������ʵ�ʾ����������������
*XTS=0��LFXTl�����ڵ�Ƶģʽ (Ĭ�ϵ�Ƶģʽ)��
*XTS=1��LFXTl�����ڸ�Ƶģʽ(������������Ӧ��Ƶʱ��Դ)��       // MSP430G2XXϵ�в�֧��XTS=1
----------------------------------------------------------------
*DIVA.0��DIVA.l����ACLK��Ƶ��
*0  ����Ƶ��Ĭ�ϲ���Ƶ����
*1  2��Ƶ��
*2  4��Ƶ��
*3  8��Ƶ��
----------------------------------------------------------------
*Rse1.0��Rsel.l��Rse1.2,Rse1.3��λ����ĳ���ڲ������Ծ���16�ֲ�ͬ�ı��Ƶ�ʡ�
*Rse1=0�� ѡ����͵ı��Ƶ�ʣ�
*Rse1=15��ѡ����ߵı��Ƶ�ʣ�
RSEL1.3 is ignored when DCOR = 1
***********************************************************************************/

/*BCSCTL2 �Ĵ���*/

/***********************************************************************************
* bit7     bit6     bit5     bit4     bit3     bit2      bit1      bit0
*SELM.1   SELM.0   DIVM.1   DIVM.0    SELS     DIVS.1    DIVS.0    DCOR
************************************************************************************
*SELM.1��SELM.0ѡ�� MCLK ʱ��Դ��
*0  ʱ��ԴΪ DCOLCK��Ĭ��ʱ��Դ����
*1  ʱ��ԴΪ DCOCLK ;
*2  ʱ��ԴΪ XT2CLK when XT2 oscillator present on-chip. LFXT1CLK or VLOCLK when XT2 oscillator not presenton-chip.��
*3  ʱ��ԴΪ LFXT1CLK or VLOCLK ��
----------------------------------------------------------------
*DIVM.1��DlVM.0ѡ�� MCLK ��Ƶ��
*0  1��Ƶ;
*1  2��Ƶ��
*2  4��Ƶ��
*3  8��Ƶ��
----------------------------------------------------------------
*   SELS Select SMCLK. This bit selects the SMCLK source.
*   0 DCOCLK
*   1 XT2CLK when XT2 oscillator present. LFXT1CLK or VLOCLK when XT2 oscillator not present.
----------------------------------------------------------------
*DIVS.1��DIVS.0ѡ�� SMCLK ��Ƶ��
*0  1��Ƶ;
*1  2��Ƶ��
*2  4��Ƶ��
*3  8��Ƶ��
----------------------------------------------------------------
*   DCOR , DCO resistor select.
*   Not available in all devices. See the device-specific data sheet.
*
*   0 Internal resistor
*   1 External resistor
*
************************************************************************************/



/*BCSCTL3 �Ĵ���*/

/************************************************************************************
* bit7      bit6    bit5     bit4     bit3    bit2      bit1     bit0
* XT2S1     XT2S0   LFXT1S1  LFXT1S0  XCAP1   XCAP0     XT2OF    LFXT1OF
************************************************************************************
*   XT2Sx   XT2 range select. These bits select the frequency range for XT2.
* XT2S1��XT2S0��2553��֧�֣�
----------------------------------------------------------------
*   LFXT1S1��LFXT1S0ѡ��LFXT1�ķ�Χ
*   Low-frequency clock select and LFXT1 range select.
    These bits select between LFXT1 and VLO when XTS =0,
    and select the frequency range for LFXT1 when XTS = 1.(MSP430G2XXX ��֧���ⲿ���پ���)
    When XTS = 0:
    00 32768-Hz crystal on LFXT1
    01 Reserved
    10 VLOCLK (Reserved in MSP430F21x1 devices)
    11 Digital external clock source
----------------------------------------------------------------
*   XCAP1��XCAP0ѡ��LFXT1��ƥ�����
    Oscillator capacitor selection.
    These bits select the effective capacitance seen by the LFXT1 crystal
    when XTS = 0. If XTS = 1 or if LFXT1Sx = 11 XCAPx should be 00.���ⲿ���پ�����Ҫ20~30P�ĵ��ݣ���Ҫ��ӣ�
* 00  1pf
* 01  6pf
* 10  10pf
* 11  12.5pf
************************************************************************************/








/***************************************************************************//**
 * @brief  Clock_DCO_Set          ��ʱ��DCOCLK��������
 * @param  ������β�Ϊx��y����ֵ�ο� datsheet DCOƵ�ʱ�
 * @return none
 *******************************************************************************/
void Clock_DCO_Set(unsigned char x,unsigned char y) // �������ΪF2618 datasheet P42
{
    unsigned char temp=( x << 4) + y; //��x,y���ϳ�1��ֵ��Ϊswitch��caseֵ

    DCOCTL &= ~(0xFF);      //DCOCTL , BCSCTL1 ȫ������
    BCSCTL1 &= ~(0xFF);

    switch(temp)
    {
    case 0x00:
    {
        DCOCTL  &=~( DCO0 + DCO1 + DCO2);
        BCSCTL1 &=~( RSEL0 + RSEL1 + RSEL2 + RSEL3);
        break;
    }
    case 0x03:
    {
        DCOCTL  |= ( DCO0 + DCO1 );
        BCSCTL1 &=~( RSEL0 + RSEL1 + RSEL2 + RSEL3);
        break;
    }
    case 0x13:
    {
        DCOCTL  |= ( DCO0 + DCO1 );
        BCSCTL1 |= ( RSEL0 );
        break;
    }
    case 0x23:
    {
        DCOCTL  |= ( DCO0 + DCO1 );
        BCSCTL1 |= ( RSEL1 );
        break;
    }
    case 0x33:
    {
        DCOCTL  |=  ( DCO0 + DCO1  );
        BCSCTL1 |= ( RSEL0 + RSEL1 );
        break;
    }
    case 0x43:
    {
        DCOCTL  |= ( DCO0 + DCO1  );
        BCSCTL1 |= ( RSEL2);
        break;
    }
    case 0x53:
    {
        DCOCTL  |= ( DCO0 + DCO1  );
        BCSCTL1 |= ( RSEL0 + RSEL2 );
        break;
    }
    case 0x63:
    {
        DCOCTL  |= ( DCO0 + DCO1  );
        BCSCTL1 |= ( RSEL1 + RSEL2 );
        break;
    }
    case 0x73:
    {
        DCOCTL  |= ( DCO0 + DCO1  );
        BCSCTL1 |= ( RSEL0 + RSEL1 + RSEL2 );
        break;
    }
    case 0x83:
    {
        DCOCTL  |= ( DCO0 + DCO1  );
        BCSCTL1 |= ( RSEL3);
        break;
    }
    case 0x93:
    {
        DCOCTL  |= ( DCO0 + DCO1  );
        BCSCTL1 |= ( RSEL0+ RSEL3);
        break;
    }
    case 0xA3:
    {
        DCOCTL  |= ( DCO0 + DCO1  );
        BCSCTL1 |= ( RSEL1 + RSEL3);
        break;
    }
    case 0xB3:
    {
        DCOCTL  |= ( DCO0 + DCO1 );
        BCSCTL1 |= ( RSEL0 + RSEL1 + RSEL3);
        break;
    }
    case 0xC3:
    {
        DCOCTL  |= ( DCO0 + DCO1 );
        BCSCTL1 |= ( RSEL2 + RSEL3);
        break;
    }
    case 0xD3:
    {
        DCOCTL  |= ( DCO0 + DCO1 );
        DCOCTL  |= ( MOD4 + MOD3 + MOD2 + MOD1 + MOD0 );//΢��DCOCLK
        BCSCTL1 |= ( RSEL0 + RSEL2 + RSEL3);
        break;
    }
    case 0xE3:
    {
        DCOCTL  |= ( DCO0 + DCO1  );
        BCSCTL1 |= ( RSEL1 + RSEL2 + RSEL3);
        break;
    }
    case 0xF3:
    {
        DCOCTL  |= ( DCO0 + DCO1  );
        BCSCTL1 |= ( RSEL0 + RSEL1 + RSEL2 + RSEL3);
        break;
    }
    case 0xF7:
    {
        DCOCTL  |= ( DCO0 + DCO1 + DCO2 );
        BCSCTL1 |= ( RSEL0 + RSEL1 + RSEL2 + RSEL3);
        break;
    }
    default:
    {
        DCOCTL  |= ( DCO0 + DCO1 + DCO2 );
        BCSCTL1 |= ( RSEL0 + RSEL1 + RSEL2 + RSEL3);
    }
    }
}


void Clock_MCLK_Div(unsigned char Div)
{
    switch(Div)                            //1��Ƶ
    {
    case 0x01:
        BCSCTL2 &=~(DIVM1 + DIVM0);
        break;
    case 0x02:                         //2��Ƶ
        BCSCTL2 &=~(DIVM1 + DIVM0);
        BCSCTL2 |=DIVM0;
        break;
    case 0x04:                         //4��Ƶ
        BCSCTL2 &=~(DIVM1 + DIVM0);
        BCSCTL2 |=DIVM1;
        break;
    case 0x08:                         //8��Ƶ
        BCSCTL2 |=(DIVM1 + DIVM0);
        break;
    default :                           //Ĭ�ϲ���Ƶ
        BCSCTL2 &=~(DIVM1 + DIVM0);
    }
}

/********************************************************************

* ������    :  SMCLK_Div
* ��������  :   ��ʱ��MCLK��������
* �����β�  :   ������β�ΪDiv����ʱ��ԴDCOCLK����Div��Ƶ
* ��������ֵ :   ��
********************************************************************/

void Clock_SMCLK_Div(unsigned char Div)
{
    switch(Div)
    {
    case 0x01:                         //1��Ƶ
        BCSCTL2 &=~(DIVS_3);
        break;
    case 0x02:                         //2��Ƶ
        BCSCTL2 &=~(DIVS_3);
        BCSCTL2 |=(DIVS_1);
        break;
    case 0x04:                         //4��Ƶ
        BCSCTL2 &=~(DIVS_3);
        BCSCTL2 |=(DIVS_2);
        break;
    case 0x08:                         //8��Ƶ
        BCSCTL2 |=(DIVS_3);
        break;
    default :                           //Ĭ�ϲ���Ƶ
        BCSCTL2 &=~(DIVS_3);
    }
}



/********************************************************************
* ������    :  ACLK_Div
* ��������  :   ��ʱ��MCLK��������
* �����β�  :   ������β�ΪDiv����ʱ��ԴLFXT1CLK����Div��Ƶ
* ��������ֵ :   ��
********************************************************************/

void Clock_ACLK_Div(unsigned char Div)
{
    switch(Div)
    {
    case 0x01:                         //1��Ƶ
        BCSCTL1 &=~(DIVA_3);
        break;
    case 0x02:                         //2��Ƶ
        BCSCTL1 &=~(DIVA_3);
        BCSCTL1 |=(DIVA_1);
        break;
    case 0x04:                         //4��Ƶ
        BCSCTL1 &=~(DIVA_3);
        BCSCTL1 |=(DIVA_2);
        break;
    case 0x08:                         //8��Ƶ
        BCSCTL1 |=(DIVA_3);
        break;
    default :                           //Ĭ�ϲ���Ƶ
        BCSCTL1 &=~(DIVA_3);
    }
}

extern void Clock_IE()      //Oscillator fault interrupt enable.
{
    IFG1 &= ~OFIFG;
    IE1 |= OFIE;
}

/***************************************************************************//**
 * @}
 ******************************************************************************/
