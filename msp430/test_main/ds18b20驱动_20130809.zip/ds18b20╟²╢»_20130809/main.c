/**********************************************
 *
 * 		Author	:		Shawn Guo
 *      Mail    :       iguoxiaopeng@gmail.com
 * 		Date	:       2013/8/6
 *      Last    :       2013/8/7
 * 		Notes	:
 * 		Tool    :
 **********************************************/

#include <msp430f2618.h>
#include "clock.h"
#include "LCD5110.h"
#include "DS18B20.h"


const unsigned char LCD_BUFFER1[] = "TEMP:";
int main()
{
    WDTCTL = WDTPW + WDTHOLD;                 // Stop WDT
    Clock_Init(0,0,0,12); // 12M DCO

    LCD5110_Init();             // LCDģ��
    LCD5110_Write_String(0,0,(char*)LCD_BUFFER1);

    P4DIR |= BIT0;
    P4REN |= BIT0;  //��������ʹ��

    while(1)
    {

        DS18B20_Temperatuer();
        LCD5110_Long2char(DS18B20_TEMPERATURE);
        LCD5110_Write_String(0,1,LCD5110_BUFFER);
    }


}
