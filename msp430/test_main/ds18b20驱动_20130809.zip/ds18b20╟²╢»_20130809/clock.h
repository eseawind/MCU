/**********************************************
 *
 * 		Author	:	Shawn Guo
 *              Mail    :       iguoxiaopeng@gmail.com
 * 		Date	:	2013/7/23
 *              Last    :       2013/8/7
 * 		Notes	:       clock system
 * 		Tool    :	MSP430x2xx
 **********************************************/
#ifndef __CLOCK_H__
#define __CLOCK_H__

/*ÿ�ζ��������õĺ궨��!!!*/
#define CPU_F       ((double)12000000)        // �����CPU_F��Ҫ�Լ����ã���������Ϊ1MHZ
#define CPU_FF      (12)                     //cpuʱ��

#define TIMERA_DIV  (1)
#define TIMERA_F    (CPU_F / TIMERA_DIV)           //TimerAʱ��

#define TIMERB_DIV  (4)
#define TIMERB_F    (CPU_F / TIMERB_DIV)           //TimerBʱ��


#define DELAY_US(x) __delay_cycles((long)(CPU_F*(double)x/1000000.0))
#define DELAY_MS(x) __delay_cycles((long)(CPU_F*(double)x/1000.0))

extern void Clock_Init(unsigned char mclk_config, unsigned char smclk_config, unsigned char aclk_config, unsigned char dco_config);
// Clock_Init(0,0,0,1); // 1M DCO
/***************************************************************************//**
 * @brief  Initialize the Clock sysyem - configure MCLK,SMCLK,ACLK,DCO
 * @param
 *      parameter               source          div
 *-----------------------------------------------------------------------------
 *      mclk_config =   0       DCO             /1
 *                      1       DCO             /2
 *                      2       DCO             /4
 *                      3       DCO             /8
 *
 *                      4       XT2             /1
 *                      5       XT2             /2
 *                      6       XT2             /4
 *                      7       XT2             /8
 *------------------------------------------------------------------------------
 *    smclk_config =    0       DCO             /1
 *                      1       DCO             /2
 *                      2       DCO             /4
 *                      3       DCO             /8
 *
 *                      4       XT2             /1
 *                      5       XT2             /2
 *                      6       XT2             /4
 *                      7       XT2             /8
 *------------------------------------------------------------------------------
 *    aclk_config =     0       VLOCLK          /1
 *                      1       VLOCLK          /2
 *                      2       VLOCLK          /4
 *                      3       VLOCLK          /8
 *
 *                      4       LFXT1           /1
 *                      5       LFXT1           /2
 *                      6       LFXT1           /4
 *                      7       LFXT1           /8
 *------------------------------------------------------------------------------
 *
 *    dco_config  =     1       1M
 *                      8       8M
 *                      12      12M
 *                      16      16M
 *
 *------------------------------------------------------------------------------
 * @return none
 ******************************************************************************/

extern void Clock_DCO_Set(unsigned char x,unsigned char y); // �������ΪF2618 datasheet P42

extern void Clock_MCLK_Div(unsigned char Div);    //�л�MCLK��Ƶϵ��,��Ӱ��ʱ��Դ
extern void Clock_SMCLK_Div(unsigned char Div);   //�л�SMCLK��Ƶϵ��,��Ӱ��ʱ��Դ
extern void Clock_ACLK_Div(unsigned char Div);    //�л�ACLK��Ƶϵ��,��Ӱ��ʱ��Դ

extern void Clock_IE();      //Oscillator fault interrupt enable.
/*************************************************************/


#endif /* __CLOCK_H__ */
