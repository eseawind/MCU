/**********************************************
 *
 * 		Author	:		Shawn Guo
 *      Mail    :       iguoxiaopeng@gmail.com
 * 		Date	:       2013/7/27
 *      Last    :       2013/8/3   ȷ��f2618 IO�˿ڼ�PWM����
 * 		Notes	:       L293N for Smart Car
 * 		Tool    :       MSP430X2XX
 **********************************************/

/*****************************************************************************
* @file       drive.c
* @addtogroup SMART CAR
* @{
******************************************************************************/
#include <msp430f2618.h>
#include "drive.h"
#include "Timer.h"
#include "clock.h"


//#define SPEED_GRITH     (6.2831 * SPEED_TIRE_R)     //С����̥�ܳ�
const long int SPEED_GRITH = (6.2831 * SPEED_TIRE_R);     //С����̥�ܳ� ��λ��mm
const int pwm_num = (int)(PWM_CLOCK / PWM_F);   // ���㶨ʱ����R0��ֵ
long int SPEED_COUNT_L = 0, SPEED_COUNT_R = 0;      //���̼�����,ÿ����һ�����̿�϶, �½����ж�ʹ��count++;

void Drive_Init(unsigned char mode, unsigned int speed)
{
    Drive_IO_Init();
    Drive_PWM_Init();

    Drive_Motor_L(mode, speed);
    Drive_Motor_R(mode, speed);
}


void Drive_IO_Init()
{
    // ����˿�         // 7 6 5 4 3 2 1 0
    P1DIR |=  0x36;     // 0 0 1 1 0 1 1 0
    P1OUT &= ~0x36;

    // ʹ�ܶ˿�
    P1DIR |= (BIT3);
    P1SEL |= (BIT3);
    P1DIR |= (BIT6);
    P1SEL |= (BIT6);
    /*
        //����IO�ж�����
        P1DIR &= ~(BIT5 + BIT7);
        P1REN |=  (BIT5 + BIT7);          //����������ʹ��
        P1OUT |=  (BIT5 + BIT7);           //����
        P1IES |=  (BIT5 + BIT7);        // �жϴ����أ������أ�
        P1IE |=   (BIT5 + BIT7);        //    ���� I/O�ж�
        P1IFG &= ~(BIT5 + BIT7);
    */
}


void Drive_PWM_Init()   //Ĭ��PWMƵ��1000HZ
{
    TimerA_UpMode_Init(2, 1, pwm_num,0,0);
    TACCTL2 = OUTMOD_7;
    TACCTL1 = OUTMOD_7;
}

void Drive_Motor_L(unsigned char mode, unsigned int speed)
{
    if(mode == 0)   //forward
        MOTOR_LEFT_GO;
    else if(mode == 1)           // backward
        MOTOR_LEFT_BACK;
    else                // stop
    {
        MOTOR_LEFT_STOP;
        return;
    }

    if(speed)       // set the new speed by pwm
        TACCR2 = (long int)(pwm_num / 100 * speed);  // MODE 7, PWM�ߵ�ƽ����ʱ�䣬����ռ�ձ�
}



void Drive_Motor_R(unsigned char mode, unsigned int speed)
{
    if(mode == 0)   //forward
        MOTOR_RIGHT_GO;
    else if(mode == 1)           // backward
        MOTOR_RIGHT_BACK;
    else                // stop
    {
        MOTOR_RIGHT_STOP;
        return;
    }

    if(speed)       // set the new speed by pwm
        TACCR1 = (long int)(pwm_num / 100 * speed );  // MODE 7, PWM�ߵ�ƽ����ʱ�䣬����ռ�ձ�
}

void Drive_Around(unsigned char mode, unsigned char angle)
{
    if(mode == 0)       //��ת        1Mʱ���²�á�
    {
        while(angle--)
        {
            Drive_Motor_L(0, 60);
            Drive_Motor_R(1, 60);
            DELAY_MS(333);
            MOTOR_LEFT_STOP;
            MOTOR_RIGHT_STOP;
        }
    }
    else                //��ת
    {
        while(angle--)
        {
            Drive_Motor_L(1, 60);
            Drive_Motor_R(0, 60);
            DELAY_MS(333);
            MOTOR_LEFT_STOP;
            MOTOR_RIGHT_STOP;
        }
    }
}


unsigned char Drive_Speed_L()
{
    return (SPEED_COUNT_L / SPEED_MAPAN * SPEED_GRITH / 1000);
}

unsigned char Drive_Speed_R()
{
    return (SPEED_COUNT_R / SPEED_MAPAN * SPEED_GRITH / 1000);
}


/***************************************************************************//**
 * @}
 ******************************************************************************/


/***************************************************************************//**
 * @brief
 * @param
 * @return none
 *******************************************************************************/
