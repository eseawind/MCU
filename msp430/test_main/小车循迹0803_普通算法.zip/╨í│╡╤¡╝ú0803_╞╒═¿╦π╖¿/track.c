/**********************************************
 *
 * 		Author	:		Shawn Guo
 *      Mail    :       iguoxiaopeng@gmail.com
 * 		Date	:       2013/7/29
 *      Last    :       2013/7/30
 * 		Notes	:       ����̽��(��ܺ���/ѭ������)
 * 		Tool    :       MSP430G2553
 *                      �����߷����+���ܹ�  --> LM339���ͱȽ���
 *                      �з������(���0), �޷�����ߡ����ߡ�(1)
 *
 **********************************************/


/*****************************************************************************
* @file       track.c
* @addtogroup TRACK for smart car
* @{
******************************************************************************/
#include <msp430f2618.h>
#include "clock.h"
#include "track.h"
#include "drive.h"



void Track_IO_Init()
{
    P2DIR &= ~(BIT0 + BIT1 + BIT2 + BIT3);
}



/*************************************************************
    TRACK_OUT4    TRACK_OUT3    TRACK_OUT2    TRACK_OUT1    ����
    0       0       0       0       ֱ��
    0       0       0       1       С��
    0       0       1       0       ����
    0       0       1       1       ����
    0       1       0       0       ����
    0       1       0       1       ����+����
    0       1       1       0       ����+����
    0       1       1       1       �����

    1       0       0       0       С��
    1       0       0       1       ����+����
    1       0       1       0       ����+����
    1       0       1       1       ����+����
    1       1       0       0       ����
    1       1       0       1       ����+����
    1       1       1       0       �����
    1       1       1       1       ����+����

    speedΪС�����ٶ� (50~100)
    ����(500ms) + ����/����(300ms)
    ����/����(5ms)
    С��/С��(3ms)
    �����/�����(15ms)


***************************************************************/
void Track_Avoiding(unsigned char speed)      //��ѭ���ܺ���ģʽ
{
    while(1)
    {
        if(TRACK_OUT4 == 0)
        {
            if(TRACK_OUT3 == 0)
            {
                if(TRACK_OUT2 == 0)  //���1: ֱ��
                {
                    if(TRACK_OUT1 == 0)
                    {
                        Drive_Motor_L(0, speed);
                        Drive_Motor_R(0, speed);
                        DELAY_MS(3);
                    }
                    else
                    {
                        Drive_Motor_L(1, speed);
                        Drive_Motor_R(0, speed);
                        DELAY_MS(3);
                    }
                }
                else    //���3,4: ����
                {
                    Drive_Motor_L(1, speed);
                    Drive_Motor_R(0, speed);
                    DELAY_MS(5);
                }
            }
            else
            {
                if(TRACK_OUT2 == 0 && TRACK_OUT1 == 0)  //���5: ����
                {
                    Drive_Motor_L(0, speed);
                    Drive_Motor_R(1, speed);
                    DELAY_MS(5);
                }
                else if(TRACK_OUT2 == 1 && TRACK_OUT1 == 1) // ���8: �����
                {
                    Drive_Motor_L(1, speed);
                    Drive_Motor_R(0, speed);
                    DELAY_MS(10);
                }
                else    //��� 6, 7: ����+����
                {
                    Drive_Motor_L(1, speed);
                    Drive_Motor_R(1, speed);
                    DELAY_MS(500);
                    Drive_Motor_L(0, speed);
                    Drive_Motor_R(1, speed);
                    DELAY_MS(300);
                }
            }
        }
        else
        {
            if(TRACK_OUT3 == 0)
            {
                if(((TRACK_OUT2) == 0) && ((TRACK_OUT1) == 0))  //���9: С��
                {
                    Drive_Motor_L(0, speed);
                    Drive_Motor_R(1, speed);
                    DELAY_MS(3);
                }
                else    //���10,11,12�� ����+����
                {
                    Drive_Motor_L(1, speed);
                    Drive_Motor_R(1, speed);
                    DELAY_MS(500);
                    Drive_Motor_L(0, speed);
                    Drive_Motor_R(1, speed);
                    DELAY_MS(300);
                }
            }
            else
            {
                if(TRACK_OUT1 == 0) //���13,15: ����
                {
                    Drive_Motor_L(0, speed);
                    Drive_Motor_R(1, speed);
                    DELAY_MS(5);
                }
                else    //���14,16�� ����+����
                {
                    Drive_Motor_L(1, speed);
                    Drive_Motor_R(1, speed);
                    DELAY_MS(500);
                    Drive_Motor_L(1, speed);
                    Drive_Motor_R(0, speed);
                    DELAY_MS(300);
                }

            }

        }
    }
}




/*************************************************************
    OUT4    OUT3    OUT2    OUT1    ����
    0       0       0       0       ����+����
    0       0       0       1       ����
    0       0       1       0       ֱ��
    0       0       1       1       С��
    0       1       0       0       ֱ��
    0       1       0       1       ֱ��
    0       1       1       0       ֱ��
    0       1       1       1       ֱ��

    1       0       0       0       ����
    1       0       0       1       ֱ��
    1       0       1       0       С��
    1       0       1       1       С��
    1       1       0       0       С��
    1       1       0       1       С��
    1       1       1       0       ֱ��
    1       1       1       1       ֹͣ

    speedΪС�����ٶ� (50~100)
    ����/����(5ms)
    С��/С��(2ms)
***************************************************************/
void Track_Following(unsigned char speed)        ////��ѭ���������ģʽ
{
    while(1)
    {
        if(TRACK_OUT4 == 0)
        {
            if(TRACK_OUT3 == 0)
            {
                if((TRACK_OUT2 == 0) )
                {
                    if(TRACK_OUT1 == 0)  // case 1: ����+����
                    {
                        Drive_Motor_L(1, speed);
                        Drive_Motor_R(1, speed);
                        DELAY_MS(300);
                        Drive_Motor_L(0, speed);
                        Drive_Motor_R(1, speed);
                        DELAY_MS(50);
                    }
                    else //case 2:����
                    {
                        Drive_Motor_L(0, speed);
                        Drive_Motor_R(1, speed);
                        DELAY_MS(5);
                    }
                }
                else
                {
                    if(TRACK_OUT1 == 0) //case 3:ֱ��
                    {
                        Drive_Motor_L(0, speed);
                        Drive_Motor_R(0, speed);
                        DELAY_MS(2);
                    }
                    else        // case 4: ����
                    {
                        Drive_Motor_L(0, speed);
                        Drive_Motor_R(1, speed);
                        DELAY_MS(2);
                    }
                }
            }
            else
            {
                if((TRACK_OUT2 == 0 ) && (TRACK_OUT1 == 0) ) // CASE 5 : ֱ��
                {
                    Drive_Motor_L(0, speed);
                    Drive_Motor_R(0, speed);
                    DELAY_MS(2);
                }
                else    // CASE 6, 7,8:ֱ��
                {
                    Drive_Motor_L(0, speed);
                    Drive_Motor_R(0, speed);
                    DELAY_MS(2);
                }

            }
        }
        else
        {
            if(TRACK_OUT3 == 0)
            {
                if((TRACK_OUT2 == 0))
                {
                    if(TRACK_OUT1 == 0) // CASE 9�� ����
                    {
                        Drive_Motor_L(1,speed);
                        Drive_Motor_R(0,speed);
                        DELAY_MS(5);
                    }
                    else    //case 10:ֱ��
                    {
                        Drive_Motor_L(0,speed);
                        Drive_Motor_R(0,speed);
                        DELAY_MS(5);
                    }
                }
                else    //case 11,12: С��
                {
                    Drive_Motor_L(0,speed);
                    Drive_Motor_R(1,speed);
                    DELAY_MS(2);
                }
            }
            else
            {

                if(TRACK_OUT2 == 0) // case  13,14:С��
                {
                    Drive_Motor_L(1,speed);
                    Drive_Motor_R(0,speed);
                    DELAY_MS(2);
                }
                else
                {
                    if(TRACK_OUT1 == 0) // case 15:ֱ��
                    {

                        Drive_Motor_L(0,speed);
                        Drive_Motor_R(0,speed);
                        DELAY_MS(5);

                    }
                    else    //CASE 16: STOP
                    {
                        Drive_Motor_L(2,speed);
                        Drive_Motor_R(2,speed);
                        DELAY_MS(2000);
                    }
                }
            }
        }

        DELAY_MS(8);
    }
}













/**
//pid MODE

unsigned char  SetValue = 0;     //�����趨ֵ, PID������������ִ��������ActualValue���մﵽ��ֵ
unsigned char  ActualValue = 0;  //����ʵ��ֵ
int  err = 0;          //����ƫ��ֵ         error--->err_next--->err_last
int  err_next = 0;     //������һ��ƫ��ֵ
int  err_last = 0;     //��¼����һ��ƫ��ֵ
unsigned char  kp,ki,kd = 0;     //�������/����/΢��ϵ��
unsigned char temp = 0;

**/



//���ݴ�������ֵת��Ϊ��Ӧ��ActualValue;
//����SetValue = 0, AcutalValue -30~30.
//OUT4  OUT3     OUT2    OUT1
// -30   -10  0  10       30
/*************************************************************
    OUT4    OUT3    OUT2    OUT1    ActualValue
    0       0       0       0       -30
    0       0       0       1       ����
    0       0       1       0       С��
    0       0       1       1       ����
    0       1       0       0       С��
    0       1       0       1       ֱ��
    0       1       1       0       ֱ��
    0       1       1       1       ֱ��

    1       0       0       0       ����
    1       0       0       1       ֱ��
    1       0       1       0       С��
    1       0       1       1       ����
    1       1       0       0       ����
    1       1       0       1       ����
    1       1       1       0       ֱ��
    1       1       1       1       ֹͣ
******************************************************/

/**
void PID_Get_ActualValue()
{
    temp = 0;
    if(TRACK_OUT4 == 1) temp += 8;
    if(TRACK_OUT3 == 1) temp += 4;
    if(TRACK_OUT2 == 1) temp += 2;
    if(TRACK_OUT1 == 1) temp += 1;

    switch(temp)
    {

    }
}

void PID_Realize()      //������PID�㷨
{
    int increment_speed = 0;

    err = SetValue - ActualValue;    // ���趨ֵ��ʵ��ֵ�������

    //�����ۼ���ֻ��洢���3�ε�����
    increment_speed = kp * (err - err_next) + ki * err +  kd * ( err - 2 *  err_next +  err_last);
    if(increment_speed > 30) increment_speed = 30;
    else if(increment_speed < -30) increment_speed = -30;
    else ;

    ActualSpeed += increment_speed;
    err_last =  err_next;                       //��¼���ֵ
    err_next =  err;

    //�õ����ֵ,������ж�Ӧ�Ĳ���
}

void Track_PID_Following(unsigned char speed)
{

}

**/

/***************************************************************************//**
 * @}
 ******************************************************************************/

/***************************************************************************//**
 * @brief
 * @param
 * @return none
 *******************************************************************************/
