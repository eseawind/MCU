/**********************************************
 *
 * 		Author	:		Shawn Guo
 *      Mail    :       iguoxiaopeng@gmail.com
 * 		Date	:       2013/8/12
 *      Last    :       2013/8/12
 * 		Notes	:       USCI_test
 * 		Tool    :       MSP430F2618
 **********************************************/

#include <msp430f2618.h>
#include "clock.h"
#include "LCD5110.h"
#include "USCI.h"
#include "NRF905.h"

unsigned char NRF905_MAIN_BUFFER[10];
unsigned char NRF905_TXADDRESS[4] = {0xcc,0xcc,0xcc,0xcc};
unsigned char NRF905_RXADDRESS[4] = {0x23,0xbb,0xcc,0xdd};
unsigned char NRF905_TXDATA[2] = {0x96, 0x69};
unsigned char NRF905_READ_FLAG = 0;
unsigned char temp = 0;
int main()
{
    WDTCTL = WDTPW + WDTHOLD;                 // Stop WDT
    Clock_Init(0,0,0,CPU_FF); // 12M DCO

    P1DIR &= ~BIT7; //  P1.5��Ϊ����
    P1IES &= ~BIT7; //  P1.5�жϴ����أ������أ�
    P1IE |= BIT7; //    ����P1.5 I/O�ж�
    P1IFG = 0;

    LCD5110_Init();

    NRF905_Init();
    NRF905_Set_RevAddress(0xcc,0xcc,0xcc,0xcc); //�޸Ľ��ܵ�ַ
    _EINT();
    //NRF905_Write_Data(NRF905_WTA, NRF905_TXADDRESS, 4);    //�趨�������ݵ�ַ
    //NRF905_Read_Data(NRF905_RTA,NRF905_MAIN_BUFFER,4);
    //NRF905_Write_Data(NRF905_WTP, NRF905_TXDATA, 2);    //�������,׼������
    //NRF905_Read_Data(NRF905_RTP,NRF905_MAIN_BUFFER,2);

    NRF905_Set_Mode(NRF905_RCV);   //�л�������ģʽ, �Ӵ�һֱ�ظ���������

    while(1)
    {
        if(NRF905_READ_FLAG == 1)
        {
            //��ȡ����.
            NRF905_READ_FLAG = 0;
            NRF905_Read_Data(NRF905_RRP,NRF905_MAIN_BUFFER,2);
            LCD5110_Long2Char(NRF905_MAIN_BUFFER[0]);
            LCD5110_Write_String(0,0,0);
            LCD5110_Long2Char(NRF905_MAIN_BUFFER[1]);
            LCD5110_Write_String(0,1,0);
        }
    }
}

#pragma vector=PORT1_VECTOR
__interrupt void P1_ISR (void)
{
    if(P1IFG & BIT7)
    {
        NRF905_READ_FLAG = 1;
    }
    P1IFG = 0;
}

