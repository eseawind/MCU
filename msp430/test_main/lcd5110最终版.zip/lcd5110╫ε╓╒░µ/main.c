/**********************************************
 *
 * 		Author	:		Shawn Guo
 *      Mail    :       iguoxiaopeng@gmail.com
 * 		Date	:       2013/8/14
 *      Last    :       2013/8/14
 * 		Notes	:       lcd5110_test
 * 		Tool    :       MSP430F2618
 **********************************************/



#include <msp430f2618.h>
#include "LCD5110.h"
#include "clock.h"
#include "USCI.h"

void main()
{
    char chs[]="guoxiaopeng";

    WDTCTL = WDTPW + WDTHOLD;
    Clock_Init(0,0,0,12); // 1M DCO

    LCD5110_Init();
    LCD5110_Write_String(0,0, chs);
    LCD5110_Long2Char((long)(655362310));
    LCD5110_Write_String(0,1,0);
}
